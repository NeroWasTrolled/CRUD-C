﻿namespace TrabalhoPicaDeCachorro
{
    partial class Trabalho
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Trabalho));
            this.Juros = new System.Windows.Forms.Label();
            this.txtJuros = new System.Windows.Forms.TextBox();
            this.Capital = new System.Windows.Forms.Label();
            this.txtCapital = new System.Windows.Forms.TextBox();
            this.Taxa = new System.Windows.Forms.Label();
            this.txtTaxa = new System.Windows.Forms.TextBox();
            this.Tempo = new System.Windows.Forms.Label();
            this.txtTempo = new System.Windows.Forms.TextBox();
            this.Fechar = new System.Windows.Forms.Button();
            this.JurosSimples = new System.Windows.Forms.Button();
            this.ValorFinal = new System.Windows.Forms.Label();
            this.Montante = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.JurosCompostos = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMontante = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Juros
            // 
            this.Juros.AutoSize = true;
            this.Juros.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Juros.ForeColor = System.Drawing.Color.Black;
            this.Juros.Location = new System.Drawing.Point(16, 28);
            this.Juros.Name = "Juros";
            this.Juros.Size = new System.Drawing.Size(67, 16);
            this.Juros.TabIndex = 0;
            this.Juros.Text = "Juros (J)";
            // 
            // txtJuros
            // 
            this.txtJuros.Location = new System.Drawing.Point(19, 63);
            this.txtJuros.Name = "txtJuros";
            this.txtJuros.Size = new System.Drawing.Size(119, 20);
            this.txtJuros.TabIndex = 1;
            this.txtJuros.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtJuros_KeyPress);
            // 
            // Capital
            // 
            this.Capital.AutoSize = true;
            this.Capital.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Capital.ForeColor = System.Drawing.Color.Black;
            this.Capital.Location = new System.Drawing.Point(16, 177);
            this.Capital.Name = "Capital";
            this.Capital.Size = new System.Drawing.Size(80, 16);
            this.Capital.TabIndex = 2;
            this.Capital.Text = "Capital (C)";
            // 
            // txtCapital
            // 
            this.txtCapital.Location = new System.Drawing.Point(19, 214);
            this.txtCapital.Name = "txtCapital";
            this.txtCapital.Size = new System.Drawing.Size(119, 20);
            this.txtCapital.TabIndex = 3;
            this.txtCapital.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCapital_KeyPress);
            // 
            // Taxa
            // 
            this.Taxa.AutoSize = true;
            this.Taxa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Taxa.ForeColor = System.Drawing.Color.Black;
            this.Taxa.Location = new System.Drawing.Point(16, 252);
            this.Taxa.Name = "Taxa";
            this.Taxa.Size = new System.Drawing.Size(60, 16);
            this.Taxa.TabIndex = 4;
            this.Taxa.Text = "Taxa (i)";
            // 
            // txtTaxa
            // 
            this.txtTaxa.Location = new System.Drawing.Point(19, 288);
            this.txtTaxa.Name = "txtTaxa";
            this.txtTaxa.Size = new System.Drawing.Size(119, 20);
            this.txtTaxa.TabIndex = 5;
            this.txtTaxa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTaxa_KeyPress);
            // 
            // Tempo
            // 
            this.Tempo.AutoSize = true;
            this.Tempo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Tempo.ForeColor = System.Drawing.Color.Black;
            this.Tempo.Location = new System.Drawing.Point(16, 322);
            this.Tempo.Name = "Tempo";
            this.Tempo.Size = new System.Drawing.Size(74, 16);
            this.Tempo.TabIndex = 6;
            this.Tempo.Text = "Tempo (t)";
            // 
            // txtTempo
            // 
            this.txtTempo.Location = new System.Drawing.Point(19, 354);
            this.txtTempo.Name = "txtTempo";
            this.txtTempo.Size = new System.Drawing.Size(119, 20);
            this.txtTempo.TabIndex = 7;
            this.txtTempo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTempo_KeyPress);
            // 
            // Fechar
            // 
            this.Fechar.BackColor = System.Drawing.Color.LightCoral;
            this.Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Fechar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Fechar.ForeColor = System.Drawing.Color.White;
            this.Fechar.Location = new System.Drawing.Point(596, 392);
            this.Fechar.Name = "Fechar";
            this.Fechar.Size = new System.Drawing.Size(192, 46);
            this.Fechar.TabIndex = 8;
            this.Fechar.Text = "FECHAR";
            this.Fechar.UseVisualStyleBackColor = false;
            this.Fechar.Click += new System.EventHandler(this.Fechar_Click);
            // 
            // JurosSimples
            // 
            this.JurosSimples.BackColor = System.Drawing.Color.RoyalBlue;
            this.JurosSimples.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.JurosSimples.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JurosSimples.ForeColor = System.Drawing.Color.Black;
            this.JurosSimples.Location = new System.Drawing.Point(16, 392);
            this.JurosSimples.Name = "JurosSimples";
            this.JurosSimples.Size = new System.Drawing.Size(192, 46);
            this.JurosSimples.TabIndex = 9;
            this.JurosSimples.Text = "JUROS SIMPLES";
            this.JurosSimples.UseVisualStyleBackColor = false;
            this.JurosSimples.Click += new System.EventHandler(this.JurosSimples_Click);
            // 
            // ValorFinal
            // 
            this.ValorFinal.AutoSize = true;
            this.ValorFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ValorFinal.ForeColor = System.Drawing.Color.Black;
            this.ValorFinal.Location = new System.Drawing.Point(241, 84);
            this.ValorFinal.Name = "ValorFinal";
            this.ValorFinal.Size = new System.Drawing.Size(0, 20);
            this.ValorFinal.TabIndex = 13;
            // 
            // Montante
            // 
            this.Montante.AutoSize = true;
            this.Montante.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Montante.ForeColor = System.Drawing.Color.Black;
            this.Montante.Location = new System.Drawing.Point(241, 155);
            this.Montante.Name = "Montante";
            this.Montante.Size = new System.Drawing.Size(0, 20);
            this.Montante.TabIndex = 14;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(443, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(345, 296);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(242, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 16);
            this.label1.TabIndex = 16;
            this.label1.Text = "Juros (J)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(242, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Montante (M)";
            // 
            // JurosCompostos
            // 
            this.JurosCompostos.BackColor = System.Drawing.Color.MediumPurple;
            this.JurosCompostos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.JurosCompostos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.JurosCompostos.ForeColor = System.Drawing.Color.White;
            this.JurosCompostos.Location = new System.Drawing.Point(245, 392);
            this.JurosCompostos.Name = "JurosCompostos";
            this.JurosCompostos.Size = new System.Drawing.Size(192, 46);
            this.JurosCompostos.TabIndex = 18;
            this.JurosCompostos.Text = "Juros Compostos";
            this.JurosCompostos.UseVisualStyleBackColor = false;
            this.JurosCompostos.Click += new System.EventHandler(this.JurosCompostos_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(16, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "Montante (M)";
            // 
            // txtMontante
            // 
            this.txtMontante.Location = new System.Drawing.Point(19, 138);
            this.txtMontante.Name = "txtMontante";
            this.txtMontante.Size = new System.Drawing.Size(119, 20);
            this.txtMontante.TabIndex = 20;
            // 
            // Trabalho
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtMontante);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.JurosCompostos);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Montante);
            this.Controls.Add(this.ValorFinal);
            this.Controls.Add(this.JurosSimples);
            this.Controls.Add(this.Fechar);
            this.Controls.Add(this.txtTempo);
            this.Controls.Add(this.Tempo);
            this.Controls.Add(this.txtTaxa);
            this.Controls.Add(this.Taxa);
            this.Controls.Add(this.txtCapital);
            this.Controls.Add(this.Capital);
            this.Controls.Add(this.txtJuros);
            this.Controls.Add(this.Juros);
            this.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Trabalho";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Trabalho Pica de Cachorro";
            this.Load += new System.EventHandler(this.Trabalho_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Juros;
        private System.Windows.Forms.TextBox txtJuros;
        private System.Windows.Forms.Label Capital;
        private System.Windows.Forms.TextBox txtCapital;
        private System.Windows.Forms.Label Taxa;
        private System.Windows.Forms.TextBox txtTaxa;
        private System.Windows.Forms.Label Tempo;
        private System.Windows.Forms.TextBox txtTempo;
        private System.Windows.Forms.Button Fechar;
        private System.Windows.Forms.Button JurosSimples;
        private System.Windows.Forms.Label ValorFinal;
        private System.Windows.Forms.Label Montante;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button JurosCompostos;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMontante;
    }
}

