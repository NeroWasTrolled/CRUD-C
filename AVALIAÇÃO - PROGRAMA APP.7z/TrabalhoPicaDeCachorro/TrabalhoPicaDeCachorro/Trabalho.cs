﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace TrabalhoPicaDeCachorro
{
    public partial class Trabalho : Form
    {
        public Trabalho()
        {
            InitializeComponent();
            InitializeComponent();
            Splash splash = new Splash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(3000);
            splash.Close();
        }

        private void Fechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtJuros_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void txtCapital_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void txtTaxa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }


        private void Trabalho_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtJuros;
            txtJuros.Focus();
            this.ActiveControl = txtCapital;
            txtCapital.Focus();
            this.ActiveControl = txtTaxa;
            txtTaxa.Focus();
            this.ActiveControl = txtTempo;
            txtTempo.Focus();

        }

        private void txtTempo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != (char)8 && e.KeyChar != (char)44)
            {
                e.Handled = true;
            }
        }

        private void JurosSimples_Click(object sender, EventArgs e)
        {
            double vf, juros, capital, taxa, tempo, montante;
          
            if (txtCapital.Text == "" || txtTaxa.Text == "" || txtTempo.Text == "" )
            {
                MessageBox.Show("Não há cálculos sem valores! Por favor, preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                capital = Convert.ToDouble(txtCapital.Text);
                taxa = Convert.ToDouble(txtTaxa.Text) / 100;
                tempo = Convert.ToDouble(txtTempo.Text);

               

                vf = (capital * taxa * tempo) / 100;
                ValorFinal.Text = vf.ToString("F");

                if (txtJuros.Text != "")
                {
                    vf = (capital * taxa * tempo) / 100;
                    montante = capital + vf;
                    Montante.Text = montante.ToString("F");
                }
                else
                {
                    Montante.Text = "";
                }
            }
        }

        private void JurosCompostos_Click(object sender, EventArgs e)
        {
            double vf, juros, capital, taxa, tempo, montante;

            if (txtCapital.Text == "" || txtTaxa.Text == "" || txtTempo.Text == "")
            {
                MessageBox.Show("Não há cálculos sem valores! Por favor, preencha todos os campos.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                capital = Convert.ToDouble(txtCapital.Text);
                taxa = Convert.ToDouble(txtTaxa.Text) / 100;
                tempo = Convert.ToDouble(txtTempo.Text);

                montante = capital * Math.Pow (1 + taxa, tempo);
                ValorFinal.Text = montante.ToString("F");

                if (txtMontante.Text != "")
                {
                    vf = montante - capital;
                    ValorFinal.Text = vf.ToString("F");
                }
                else
                {
                    ValorFinal.Text = "";
                }
            }
        }
    }
}
